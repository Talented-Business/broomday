
		    window.onload = function () {   
		       $('#customer_user').select2('focus');
$('#customer_user').select2('open');
            };
