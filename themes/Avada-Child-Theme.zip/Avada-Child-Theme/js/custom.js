jQuery(document).ready(function(){
    jQuery('.buttonc').click(function(){
        alert('sdfsdasdf');
    });
    var $sticky = jQuery('.checkout-sidebar>:first-child');
    var $stickyrStopper = jQuery('.fusion-footer');
    var stickOffset = 10;
    var windowTop,stickyTop,diff,stopPoint,generalSidebarHeight;
    if (!!$sticky.offset()&&jQuery(window).innerWidth()>1182) { // make sure ".sticky" element exists
  
      generalSidebarHeight = $sticky.innerHeight();
      stickyTop = $sticky.offset().top;
      var stickyStopperPosition = $stickyrStopper.offset().top;
  
      jQuery(window).scroll(function(){ // scroll event
        windowTop = jQuery(window).scrollTop(); // returns number
        moveSidebar();
      });
    }
    var moveSidebar = function(){
        let basic_height = parseInt(jQuery("#customer_details").css("height"));
        if(basic_height<generalSidebarHeight){
            $sticky.css({ position: 'relative', top: 0 });
            return;
        }
        stopPoint = stickyStopperPosition - generalSidebarHeight - stickOffset;
        diff = stopPoint + stickOffset-stickyTop;
          if (stopPoint < windowTop) {
            $sticky.css({ position: 'absolute', top: diff });
        } else if (stickyTop < windowTop+stickOffset) {
            $sticky.css({ position: 'fixed', top: stickOffset });
        } else {
            $sticky.css({position: 'absolute', top: 'initial'});
        }
    }  
    jQuery('.col-box-new .collapse').on('hidden.bs.collapse', function (event) {
        generalSidebarHeight = $sticky.innerHeight();
        console.log(parseInt(jQuery("#"+event.target.id).css("height")));
        moveSidebar();
    })
    jQuery('.col-box-new .collapse').on('shown.bs.collapse', function (event) {
        console.log(parseInt(jQuery("#"+event.target.id).css("height")));
        //stickOffset -=parseInt(jQuery("#"+event.target.id).css("height"));
        generalSidebarHeight = $sticky.innerHeight();
        moveSidebar();
    })
    jQuery('.col-box-new .collapse').on('hide.bs.collapse', function (event) {
        //stickOffset +=parseInt(jQuery("#"+event.target.id).css("height"));
        jQuery("a[href=#"+event.target.id+"] i").removeClass("fa-chevron-down").addClass("fa-chevron-right");
    })
    jQuery('.col-box-new .collapse').on('show.bs.collapse', function (event) {
        jQuery("a[href=#"+event.target.id+"] i").removeClass("fa-chevron-right").addClass("fa-chevron-down");
    })
});
function myfunc(val){
    
   var coupon_code = jQuery('.checkout_coupon #coupon_code').val();
   if(coupon_code == ''){
        alert('por favor ingrese el código');
        return false;
   }
    jQuery('.msg').text('Por favor espera..');
    var data = {
        security: wc_cart_params.apply_coupon_nonce,
        coupon_code: coupon_code
    };
    /*jQuery.ajax({
        url: ajax_object.ajax_url,
        type: 'post',
        dataType: 'json',
        success: function (data) {
            alert(data.msg);
            jQuery('.msg').text('');
            jQuery('body').trigger('update_checkout');
            jQuery('.checkout_coupon #coupon_code').focus();
            setTimeout(function () {
                jQuery('body').trigger('update_checkout');
            }, 100);
           //jQuery( 'body' ).trigger( 'update_checkout' );
           //location.reload();
        },
        data: data
    }); */
    var get_url = function( endpoint ) {
		return wc_cart_params.wc_ajax_url.toString().replace(
			'%%endpoint%%',
			endpoint
		);
	};
    var show_notice = function( html_element, $target ) {
		if ( ! $target ) {
			$target = jQuery( '.woocommerce-notices-wrapper:first' ) || jQuery( '.cart-empty' ).closest( '.woocommerce' ) || jQuery( '.woocommerce-cart-form' );
		}
		$target.prepend( html_element );
    };
    jQuery.ajax( {
        type:     'POST',
        url:      get_url( 'apply_coupon' ),
        data:     data,
        dataType: 'html',
        success: function( response ) {
            jQuery( '.woocommerce-error, .woocommerce-message, .woocommerce-info' ).remove();
            jQuery('.msg').text('');
            //show_notice( response );
            jQuery( document.body ).trigger( 'applied_coupon', [ coupon_code ] );
        },
        complete: function() {
            jQuery('.checkout_coupon #coupon_code').val( '' );
            jQuery( 'body' ).trigger( 'update_checkout' );
        }
    } );

}
/*window.onbeforeunload = function() {
    localStorage.setItem(billing_first_name, jQuery('#billing_first_name').val());
    localStorage.setItem(billing_last_name, jQuery('#billing_last_name').val());
    localStorage.setItem(billing_phone, jQuery('#billing_phone').val());
    localStorage.setItem(billing_cell, jQuery('#billing_cell').val());
    localStorage.setItem(billing_address_1, jQuery('#billing_address_1').val());
    localStorage.setItem(service_description, jQuery('#service_description').val());
    localStorage.setItem(billing_comments,jQuery('#billing_comments').val());
    localStorage.setItem(cust_latitude, jQuery('#cust_latitude').val());
    localStorage.setItem(cust_longitude, jQuery('#cust_longitude').val());
    localStorage.setItem(billing_email, jQuery('#billing_email').val()); 
    localStorage.setItem(extra_service_name, jQuery('#extra_service_name').val());
}

window.onload = function() {

    var billing_first_name = localStorage.getItem(billing_first_name);
    var billing_last_name = localStorage.getItem(billing_last_name);
    var billing_phone = localStorage.getItem(billing_phone);
    var billing_cell = localStorage.getItem(billing_cell);
    var billing_address_1 = localStorage.getItem(billing_address_1);
    var service_description = localStorage.getItem(service_description);
    var billing_comments = localStorage.getItem(billing_comments);
    var cust_latitude = localStorage.getItem(cust_latitude);
    var cust_longitude = localStorage.getItem(cust_longitude);
    var billing_email = localStorage.getItem(billing_email);
    var extra_service_name = localStorage.getItem(extra_service_name);
    
    if (billing_first_name !== null) jQuery('#billing_first_name').val(billing_first_name);
    if (billing_last_name !== null) jQuery('#billing_last_name').val(billing_last_name);
    if (billing_phone !== null) jQuery('#billing_phone').val(billing_phone);
    if (billing_cell !== null) jQuery('#billing_cell').val(billing_cell);
    if (billing_address_1 !== null) jQuery('#billing_address_1').val(billing_address_1);
    if (service_description !== null) jQuery('#service_description').val(service_description);
    if (billing_comments !== null) jQuery('#billing_comments').val(billing_comments);
    if (cust_latitude !== null) jQuery('#cust_latitude').val(cust_latitude);
    if (cust_longitude !== null) jQuery('#cust_longitude').val(cust_longitude);
    if (billing_email !== null) jQuery('#billing_email').val(billing_email);
    if (extra_service_name !== null) jQuery('#extra_service_name').val(extra_service_name);
}*/