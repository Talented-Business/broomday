<div class="fusion-link-selector">
	<input id="{{ param.param_name }}" name="{{ param.param_name }}" type="text" class="regular-text fusion-builder-link-field" value="{{ option_value }}" />
	<input type='button' class='button-link-selector fusion-builder-link-button' value='{{ fusionBuilderText.select_link }}'/>
</div>
