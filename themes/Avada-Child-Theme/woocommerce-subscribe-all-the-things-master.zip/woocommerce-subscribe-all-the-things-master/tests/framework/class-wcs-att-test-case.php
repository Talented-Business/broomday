<?php
/**
 * SATT Test Case
 *
 * @author   SomewhereWarm <sw@somewherewarm.net>
 * @package  WooCommerce Subscribe All The Things
 * @since    1.2.0
 */

/**
 * CP test case class.
 *
 * @since 1.2.0
 */
class WCS_ATT_Test_Case extends WP_UnitTestCase {

	protected $factory;

	/**
	 * Set up the test case.
	 *
	 * @since 1.2.0
	 */
	public function setUp() {
		parent::setUp();
	}
}
